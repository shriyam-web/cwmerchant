import Partner from "./partner.schema";

export default Partner;
